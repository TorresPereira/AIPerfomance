# ⌚ Garmin Daily Briefing

Receba todo dia às **6h da manhã** um e-mail com seus dados de saúde e treino do Garmin Connect — HRV, sono, readiness, carga (ACWR), VO₂max, peso e previsão de prova — com semáforos visuais e a ação do dia.

Roda 100% na nuvem via **GitHub Actions** (grátis). Nenhum computador precisa ficar ligado.

---

## 🚀 Setup em 5 passos

### 1. Crie o repositório no GitHub

1. Acesse [github.com](https://github.com) e faça login
2. Clique em **New repository**
3. Dê um nome (ex: `garmin-briefing`)
4. Marque **Private** (importante — suas credenciais ficam aqui)
5. Clique em **Create repository**

---

### 2. Faça upload dos arquivos

No repositório criado, clique em **uploading an existing file** e envie:
- `garmin_briefing.py`
- `.github/workflows/briefing.yml` *(crie a pasta `.github/workflows` antes ou use o upload por zip)*

**Dica:** Baixe o ZIP com todos os arquivos e faça upload de uma vez.

---

### 3. Crie uma conta SendGrid e verifique o remetente

1. Acesse [sendgrid.com](https://sendgrid.com) → **Start for Free**
2. Crie conta (plano gratuito: 100 e-mails/dia)
3. No painel: **Settings → Sender Authentication → Single Sender Verification**
4. Cadastre o e-mail que vai aparecer como remetente (ex: `briefing@gmail.com`)
5. Confirme o link que o SendGrid vai enviar para esse e-mail
6. Vá em **Settings → API Keys → Create API Key**
7. Selecione **Full Access** → **Create & View**
8. **Copie a chave** (começa com `SG.…`) — ela só aparece uma vez!

---

### 4. Configure os Secrets no GitHub

No seu repositório: **Settings → Secrets and variables → Actions → New repository secret**

Crie os 5 secrets abaixo:

| Nome | Valor |
|------|-------|
| `GARMIN_EMAIL` | Seu e-mail do Garmin Connect |
| `GARMIN_PASSWORD` | Sua senha do Garmin Connect |
| `SENDGRID_API_KEY` | A chave `SG.…` copiada no passo anterior |
| `EMAIL_FROM` | E-mail verificado no SendGrid (remetente) |
| `EMAIL_TO` | Seu e-mail onde quer receber o briefing |

---

### 5. Teste manualmente

1. No repositório, clique em **Actions**
2. Selecione o workflow **Garmin Daily Briefing**
3. Clique em **Run workflow → Run workflow**
4. Aguarde ~1 minuto e verifique sua caixa de entrada

Se tudo der certo, o briefing vai rodar automaticamente todo dia às **6h** (horário de Brasília). ✅

---

## 🔍 Entendendo os semáforos

| Semáforo | Significado |
|----------|-------------|
| 🟢 | Ótimo — pode treinar com intensidade |
| 🟡 | Moderado — treino leve ou técnico |
| 🔴 | Baixo — priorize recuperação |
| ⚪ | Dado não disponível |

### Limiares usados

| Métrica | 🔴 | 🟡 | 🟢 |
|---------|----|----|-----|
| HRV | < 40 ms | 40–60 ms | > 60 ms |
| Sono (score) | < 60 | 60–80 | > 80 |
| Readiness / Body Battery | < 40 | 40–70 | > 70 |
| ACWR | > 1.5 (sobrecarga) | < 0.8 ou 1.3–1.5 | 0.8–1.3 (ideal) |

---

## 🛠️ Problemas comuns

**"Login failed" no Garmin**
→ A Garmin às vezes exige verificação em dois fatores. Tente logar pelo app e aprovar a sessão nova.

**E-mail não chegou**
→ Verifique o spam. Confirme que o `EMAIL_FROM` foi verificado no SendGrid.

**Dados aparecem como `—`**
→ Alguns dados (ex: peso, HRV) só aparecem se você tiver dispositivos compatíveis e tiver sincronizado no dia anterior. Normal na primeira execução.

---

## 📊 Dados coletados

- **HRV** — variabilidade da frequência cardíaca noturna (ms)
- **Sono** — duração total, score, sono profundo e REM
- **Readiness** — Body Battery ao acordar (proxy de prontidão)
- **ACWR** — relação carga aguda/crônica (Acute:Chronic Workload Ratio)
- **VO₂max** — capacidade aeróbica estimada (ml/kg/min)
- **Peso** — último registro do dia (se disponível)
- **Previsão de prova** — tempos estimados para 5K, 10K, Meia e Maratona
